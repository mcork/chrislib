#include "Algorithms.h"

Algorithms::Algorithms() {
	Algorithms::xCenter = -1;
	Algorithms::yCenter = -1;
	Algorithms::threshold = 100;
	Algorithms::lastPoint.x = -1;
	Algorithms::lastPoint.y = -1;
	Algorithms::presentPoint.x = -1;
	Algorithms::presentPoint.y = -1;
	Algorithms::tryPoint.x = -1;
	Algorithms::tryPoint.y = -1;
	Algorithms::captureFPS = 1;
	Algorithms::captureHeight = 480;
	Algorithms::captureWidth = 640;
	Algorithms::wantToClic = false;
	Algorithms::keyPress = false;
	Algorithms::flipVertical = false;
	Algorithms::Blur = false;
	Algorithms::step = 1;
	Algorithms::deep = 0;

	
	

	Algorithms::choice=3;


	Algorithms::circle = false;
	Algorithms::report = false;
	Algorithms::move = false;
	Algorithms::calibrate = false;
	Algorithms::difer = false;
	Algorithms::haveCalibrate = false;
	Algorithms::restartBackground = false;
	Algorithms::Quit=false;
}

Algorithms::Algorithms(int thresholdValue) {
	Algorithms();
	
	Algorithms::xCenter = -1;
	Algorithms::yCenter = -1;
	Algorithms::threshold = thresholdValue;
	
}

Algorithms::~Algorithms() {

	// Threads
#ifdef WIN32
	if(hThread)
		TerminateThread(hThread, 0);
#else
	if(hThread){
		pthread_kill(hThread,15);
		hThread = 0;
	}
#endif

	cvReleaseCapture(&capture);
	cvDestroyWindow("Whiteboard Process");
	if (debug) {
		cvDestroyWindow("View");
	}

}

void Algorithms::setAlgorithm(int value)
{
	Algorithms::choice=value;
}



void Algorithms::distance(int max) {
	int seX = -1, seY = -1;
	int idX = 1, idY = 1;
	int i;
	int circles = 1;
	coordinate c = { 0, 0 };
	vDistance.push_back(c);

	//if(jump==0)
	//	jump=1;

	//printf("\n\nJUMP %d",jumpValue);

	do {
		//printf("\n\nCiclo numero: %d\n",circles);


		for (i = seX; i <= idX; i += jumpValue) {
			c.x = i;
			c.y = seY;
			vDistance.push_back(c);
		}

		for (i = seY + 1; i <= idY; i += jumpValue) {
			c.x = idX;
			c.y = i;
			vDistance.push_back(c);
		}

		for (i = idX - 1; i >= seX; i -= jumpValue) {
			c.x = i;
			c.y = idY;
			vDistance.push_back(c);
		}

		for (i = idY - 1; i > seY; i -= jumpValue) {
			c.x = seX;
			c.y = i;
			vDistance.push_back(c);
		}

		seX--;
		seY--;

		idX++;
		idY++;

		circles++;

	} while (circles <= max);
	//printf("\nSize %d\n", (int) vDistance.size());
}

void Algorithms::printCircle(coordinate center, IplImage* frame) {
	// para mostrar a zona onde foi encontrado
	if (center.x >= 0 && center.y >= 0) {
		CvPoint c;
		c.x = center.x;
		c.y = center.y;

		cvCircle(frame, c, 5, CV_RGB(255, 0, 0), CV_FILLED, CV_AA, 0);
	}
}



coordinate Algorithms::processCenter() {
	int xTemp = 0, yTemp = 0;
	coordinate center = { -1, -1 };
	//puts("ProcessCenter");
	for (int i = 0; i < (int) xValues.size(); i++) {
		//printf("%d",i);
		xTemp = xTemp + (int) xValues.at(i);
		yTemp = yTemp + (int) yValues.at(i);
	}

	center.x = (int) (xTemp / xValues.size());
	//printf("%d",xCenter);
	center.y = (int) (yTemp / yValues.size());
	//printf("%d",yCenter);

	return center;
}

coordinate Algorithms::findCenter(coordinate temp, IplImage* frame) {
	coordinate center = { -1, -1 };
	int xMax = 0, xMin = 0, yMax = 0, yMin = 0;

	int pointer = (temp.y * frame->width + temp.x);

	for (int p = pointer; p < ((temp.y + 1) * frame->width - 1)
		&& frame->imageData[p] >= threshold; xMax++, p++)
		;
	for (int p = pointer; p > ((temp.y) * frame->width) && frame->imageData[p]
	>= threshold; xMin--, p--)
		;

	int distance = xMax - xMin;
	center.x = temp.x + int(distance / 2);

	//adjust pointer
	pointer = (temp.y * frame->width + center.x);

	for (int p = pointer; p < (frame->height + center.x - 1)
		&& frame->imageData[p] >= threshold; yMax++, p += frame->width)
		;
	for (int p = pointer; p > (center.x) && frame->imageData[p] >= threshold; yMin--, p
		-= frame->width)
		;

	distance = yMax - yMin;
	center.y = temp.y + int(distance / 2);

	return center;

}

void Algorithms::cleanVector() {
	//puts("CleanVector");
	if (xValues.size() > 0) {
		xValues.erase(xValues.begin(), xValues.end());
		yValues.erase(yValues.begin(), yValues.end());
	}

	//printf("\nClean vector xValues (%d) and yValues (%d)",(int) xValues.size(),(int) yValues.size());
}

void Algorithms::cleanVectorResults() {
	//puts("CleanVector");
	if (results.size() > 0) {
		results.erase(results.begin(), results.end());
	}
}

void Algorithms::qtMove(int x, int y) {
	if (x > -1 && y > -1)
		QCursor::setPos(x, y);
}

void Algorithms::screenSize() {

	//int w = QApplication::desktop()->width();
	//int h = QApplication::desktop()->height();

	//printf("Screen Resolution x= %d y=%d", w, h);
}

int Algorithms::convertToResolution(int p, int escalaOrigem, int escalaDestino) {
	return (p * escalaDestino) / escalaOrigem;
}

vector<coordinate> Algorithms::detectBlobs(IplImage* frame,
										   IplImage* finalFrame) {
											   // http://geekblog.nl/entry/24
											   // 28 outubro 2008
											   int blobCounter = 0;
											   map<unsigned int, blob> blobs;

											   vector<vector<lineBlob> > imgData(frame->width);

											   for (int row = 0; row < frame->height; ++row) {

												   for (int column = 0; column < frame->width; ++column) {

													   //unsigned char byte = (unsigned char) imgStream.get();
													   unsigned char byte = (unsigned char) frame->imageData[(row
														   * frame->width) + column];

													   if (byte >= threshold) {
														   int start = column;

														   for (; byte >= threshold; byte
															   = (unsigned char) frame->imageData[(row * frame->width)
															   + column], ++column)
															   ;

														   int stop = column - 1;
														   lineBlob lineBlobData = { start, stop, blobCounter, false };

														   imgData[row].push_back(lineBlobData);
														   blobCounter++;
													   }
												   }
											   }

											   /* Check lineBlobs for a touching lineblob on the next row */

											   for (int row = 0; row < (int) imgData.size(); ++row) {

												   for (int entryLine1 = 0; entryLine1 < (int) imgData[row].size(); ++entryLine1) {

													   for (int entryLine2 = 0; entryLine2 < (int) imgData[row + 1].size(); ++entryLine2) {

														   if (!((imgData[row][entryLine1].max
															   < imgData[row + 1][entryLine2].min)
															   || (imgData[row][entryLine1].min
															   > imgData[row + 1][entryLine2].max))) {

																   if (imgData[row + 1][entryLine2].attached == false) {

																	   imgData[row + 1][entryLine2].blobId
																		   = imgData[row][entryLine1].blobId;

																	   imgData[row + 1][entryLine2].attached = true;
																   } else

																   {
																	   imgData[row][entryLine1].blobId
																		   = imgData[row + 1][entryLine2].blobId;

																	   imgData[row][entryLine1].attached = true;
																   }
														   }
													   }
												   }
											   }

											   // Sort and group blobs

											   for (int row = 0; row < (int) imgData.size(); ++row) {

												   for (int entry = 0; entry < (int) imgData[row].size(); ++entry) {

													   if (blobs.find(imgData[row][entry].blobId) == blobs.end()) // Blob does not exist yet

													   {
														   coordinate min = { imgData[row][entry].min, row };
														   coordinate max = { imgData[row][entry].max, row };
														   coordinate center = { 0, 0 };

														   blob blobData = { min, max, center };

														   blobs[imgData[row][entry].blobId] = blobData;
													   } else

													   {
														   if (imgData[row][entry].min
															   < blobs[imgData[row][entry].blobId].min.x)

															   blobs[imgData[row][entry].blobId].min.x
															   = imgData[row][entry].min;

														   else if (imgData[row][entry].max
															   > blobs[imgData[row][entry].blobId].max.x)

															   blobs[imgData[row][entry].blobId].max.x
															   = imgData[row][entry].max;

														   if (row < (int) blobs[imgData[row][entry].blobId].min.y)

															   blobs[imgData[row][entry].blobId].min.y = row;

														   else if (row > (int) blobs[imgData[row][entry].blobId].max.y)

															   blobs[imgData[row][entry].blobId].max.y = row;
													   }
												   }
											   }

											   // Calculate center
											   for (map<unsigned int, blob>::iterator i = blobs.begin(); i != blobs.end(); ++i) {
												   (*i).second.center.x = (*i).second.min.x + ((*i).second.max.x
													   - (*i).second.min.x) / 2;
												   (*i).second.center.y = (*i).second.min.y + ((*i).second.max.y
													   - (*i).second.min.y) / 2;

												   int size = ((*i).second.max.x - (*i).second.min.x) * ((*i).second.max.y
													   - (*i).second.min.y);

												   // Print coordinates on image, if it is large enough
												   cleanVectorResults();

												   if (size > 5) {
													   CvFont font;
													   cvInitFont(&font, CV_FONT_HERSHEY_PLAIN, 1.0, 1.0, 0, 1, CV_AA);

													   char textBuffer[128];

													   coordinate temp = { (*i).second.center.x, (*i).second.center.y };

													   // Draw crosshair and print coordinates (just for debugging, not necessary for later multi-touch use)
													   cvLine(finalFrame, cvPoint(temp.x - 5, temp.y), cvPoint(temp.x + 5,
														   temp.y), cvScalar(0, 255, 0), 1);

													   cvLine(finalFrame, cvPoint(temp.x, temp.y - 5), cvPoint(temp.x,
														   temp.y + 5), cvScalar(0, 255, 0), 1);

													   sprintf(textBuffer, "(%d, %d)", temp.x, temp.y);

													   cvPutText(finalFrame, textBuffer, cvPoint(temp.x + 5, temp.y - 5),
														   &font, cvScalar(0, 255, 0));

													   cvRectangle(finalFrame, cvPoint((*i).second.min.x,
														   (*i).second.min.y), cvPoint((*i).second.max.x,
														   (*i).second.max.y), cvScalar(0, 255, 0), 1);

													   results.push_back(temp);
												   }
											   }
											   return results;
}

coordinate Algorithms::singlePointProcess(IplImage* workFrame) {
	cleanVector();

	for (int row = 0; row < workFrame->height; ++row) {
		for (int column = 0; column < workFrame->width; ++column) {
			//unsigned char byte = (unsigned char) workFrame->imageData[(row*workFrame->width)+ column];

			if (workFrame->imageData[(row * workFrame->width) + column]
			>= threshold) {
				xValues.push_back(column);
				yValues.push_back(row);
				//printf("Ponto com informação x: %d y: %d \n", x, y);
			}
		}
	}

	coordinate center = { -1, -1 };

	if (xValues.size() > 0) {
		center = processCenter();
	}

	return center;
}

coordinate Algorithms::singlePointProcess(IplImage* workFrame, int step) {
	cleanVector();

	for (int row = 0; row < workFrame->height; ++row) {
		for (int column = 0; column < workFrame->width; column += step) {
			//unsigned char byte = (unsigned char) workFrame->imageData[(row*workFrame->width)+ column];

			if (workFrame->imageData[(row * workFrame->width) + column]
			>= threshold) {
				xValues.push_back(column);
				yValues.push_back(row);
				//printf("Ponto com informação x: %d y: %d \n", x, y);
			}
		}
	}

	coordinate center = { -1, -1 };

	if (xValues.size() > 0) {
		center = processCenter();
	}

	return center;
}

coordinate Algorithms::singlePointProcessPTR(IplImage* workFrame) {
	int max = (workFrame->height * workFrame->width) - 1;
	for (int count = 0; count < max; count++) {
		//unsigned char byte = (unsigned char) workFrame->imageData[count];

		if (workFrame->imageData[count] >= threshold) {
			int column = (int) (count % workFrame->width);
			int row = (int) (count / workFrame->width);

			coordinate temp = { column, row };

			coordinate center = findCenter(temp, workFrame);

			//printf("Ponto com informação x: %d y: %d \n", center.x , center.y );

			return center;
			//printf("Ponto com informação x: %d y: %d \n", x, y);
		}
	}

	coordinate center = { -1, -1 };

	return center;
}

coordinate Algorithms::singlePointProcessPTR(IplImage* workFrame, int step) {
	int max = (workFrame->height * workFrame->width) - 1;
	for (int count = 0; count < max; count += step) {
		//unsigned char byte = (unsigned char) workFrame->imageData[count];

		if (*(workFrame->imageData + count) >= threshold) {
			int column = (int) (count % workFrame->width);
			int row = (int) (count / workFrame->width);

			coordinate temp = { column, row };

			coordinate center = findCenter(temp, workFrame);

			//printf("Ponto com informação x: %d y: %d \n", center.x , center.y );

			return center;
			//printf("Ponto com informação x: %d y: %d \n", x, y);
		}
	}

	coordinate center = { -1, -1 };

	return center;
}

coordinate Algorithms::spiral(IplImage* workFrame, int x, int y) {
	int seX = x - 1, seY = y - 1;
	int idX = x + 1, idY = y + 1;
	int i;
	int cicles = 1;
	coordinate c = { -1, -1 };

	bool keepon = true;

	do {
		//printf("\n\nCiclo numero: %d\n",cicles);

		//printf("SE (%d / %d)\n",seX,seY);
		//printf("ID (%d / %d)\n",idX,idY);


		for (i = seX; i <= idX && i <= workFrame->width && i >= 0; i += step) {
			//printf("Pesquisa na coordenada c(%d / %d)\n",i,seY);
			if ((unsigned char) workFrame->imageData[(seY * workFrame->width)
				+ i] >= threshold) {
					//puts("primeiro ciclo spiral");
					c.x = i;
					c.y = seY;
					return c;
			}
		}

		for (i = seY + 1; i <= idY && i <= workFrame->height && i >= 0; i
			+= step) {
				//printf("Pesquisa na coordenada c(%d / %d)\n",sdX,i);
				if ((unsigned char) workFrame->imageData[(i * workFrame->width)
					+ idX] >= threshold) {
						//puts("segundo ciclo spiral");
						c.x = idX;
						c.y = i;
						return c;
				}
		}

		for (i = idX - 1; i >= seX && i <= workFrame->width && i >= 0; i
			-= step) {
				//printf("Pesquisa na coordenada c(%d / %d)\n",i,idY);
				if ((unsigned char) workFrame->imageData[(idY * workFrame->width)
					+ i] >= threshold) {
						//puts("terceiro ciclo spiral");
						c.x = i;
						c.y = idY;
						return c;
				}
		}

		for (i = idY - 1; i > seY && i <= workFrame->height && i >= 0; i
			-= step) {
				//printf("Pesquisa na coordenada c(%d / %d)\n",ieX,i);
				if ((unsigned char) workFrame->imageData[(i * workFrame->width)
					+ seX] >= threshold) {
						//puts("quarto ciclo spiral");
						c.x = seX;
						c.y = i;
						return c;
				}
		}

		if (seX == 0 && seY == 0 && idX == workFrame->width && idY
			== workFrame->height)
			keepon = false;

		seX = seX > 0 ? seX - step : 0;
		seY = seY > 0 ? seY - step : 0;

		idX = idX < workFrame->width ? idX + step : workFrame->width;
		idY = idY < workFrame->height ? idY + step : workFrame->height;

		cicles++;
	} while (keepon);

	//puts("no PI !!\n");
	return c;
}

coordinate Algorithms::spiral2(IplImage* workFrame, int x, int y) {
	coordinate temp = { -1, -1 };
	spiralTentatives++;
	for (int i = 0; i < (int) vDistance.size(); i++) {
		int pointer = (y + vDistance.at(i).y) * workFrame->width + (x
			+ vDistance.at(i).x);
		//printf("\nPOINTER %d\n",pointer);
		//unsigned char byte= (unsigned char) workFrame->imageData[pointer];
		if (workFrame->imageData[pointer] >= threshold) {
			//puts("\n\tEncontrou ponto na espiral !!");
			temp.x = (int) pointer % workFrame->width;
			temp.y = (int) pointer / workFrame->width;
			//printf("\t (%d,%d)\n",temp.x,temp.y);
			spiralSuceeded++;
			return temp;
		}
	}

	//puts("\n\tTentativa fora da espiral !!");
	temp = singlePointProcessPTR(workFrame, step);
	return temp;
}

coordinate Algorithms::smartSinglePointProcess(IplImage* workFrame) {

	//puts("\n\n---------------------\nStart - Smart\n------------------------\n\n");

	int xPrediction = 0, yPrediction = 0;
	coordinate center = { -1, -1 };
	coordinate temp = { -1, -1 };
	bool prevision = false;

	//printf("\n------------------------------------------------------------------------------------------------------------\nvalor do ponto anterior %d / %d\n",xCenter,yCenter);

	// se a previsão for fora dos limites da frame começar do centro
	// if((xCenter+xDelta)<=0 || (xCenter+xDelta)>workFrame->width)
	// {
	//	xPrediction=(workFrame->width/2);
	// }
	// else
	// {
	//	xPrediction=xCenter+xDelta;
	// }
	// if((yCenter+yDelta)<=0 || (yCenter+yDelta)>workFrame->height)
	// {
	//	yPrediction=(workFrame->height/2);
	// }
	// else
	// {
	//	yPrediction=yCenter+yDelta;
	// }

	//printf("spiral começa sobre o ponto estimado %d / %d\n",xPrediction,yPrediction);
	//printf("valor de delta %d / %d\n",xDelta,yDelta);


	//coordinate temp=spiral(workFrame,xPrediction, yPrediction);

	if (presentPoint.x != -1 && presentPoint.y != -1 && lastPoint.x != -1
		&& lastPoint.y != -1) {
			xDelta = (presentPoint.x - lastPoint.x);
			yDelta = (presentPoint.y - lastPoint.y);
			prevision = true;
	} else {
		xDelta = 0;
		yDelta = 0;
		prevision = false;
	}

	//printf("valor de delta %d / %d\n",xDelta,yDelta);

	if (prevision && presentPoint.x + xDelta <= workFrame->width
		&& presentPoint.y + yDelta <= workFrame->height) {
			xPrediction = presentPoint.x + xDelta;
			yPrediction = presentPoint.y + yDelta;
			// printf("\nHeight: %d  Width: %d\n",workFrame->height,workFrame->width);
			// printf("\nPrediction x: %d y:%d \n", xPrediction,yPrediction);
			temp = spiral2(workFrame, xPrediction, yPrediction);
	} else {
		// puts("Sem previsão");
		// metodo normal não ha previsão

		//puts("\n\n---------------------\nEnd 1 - Smart\n------------------------\n\n");

		return singlePointProcessPTR(workFrame, step);

	}

	if (temp.x != -1 && temp.y != -1) {

		//printf("\nSpiral encontrou este ponto TEMP: %d %d \n",temp.x,temp.y);

		// processar centro do PI
		center = findCenter(temp, workFrame);

		//printf("\nCenter Value after findCenter temp (%d,%d)\n",center.x,center.y);

		// actualizar o delta
		//if((temp.x-xCenter)<=workFrame->width && (temp.y-yCenter)<=workFrame->height)
		//{
		//	xDelta=temp.x-xCenter;
		//	yDelta=temp.y-yCenter;
		//}

		//printf("novo valor de delta %d / %d\n------------------------------------------------------------------------------------------------------------\n\n\n\n\n\n\n\n\n\n\n",xDelta,yDelta);
		//getchar();

		// guardar nova posição do PI
		//center.x=temp.x;
		//center.y=temp.y;

	}

	//puts("\n\n---------------------\nEnd 2 - Smart\n------------------------\n\n");

	return center;

}

void Algorithms::reportCoordinate(coordinate temp) {
	if (temp.x >= 0 && temp.y >= 0)
		printf("\n%d\t\t%d", temp.x, temp.y);
}

void Algorithms::initialize(int argc, char *argv[]) {
	capture = 0;
	if (cam) {
		// verifica se passamos argumentos na linhda de comandos
		if (argc == 1 || (argc == 2 && strlen(argv[1]) == 1 && isdigit(
			argv[1][0])))
			capture = cvCaptureFromCAM(argc == 2 ? argv[1][0] - '0' : 0);
		else if (argc == 2)
			capture = cvCaptureFromAVI(argv[1]);
	} else {
		// começa os testes a partir do mesmo film
		if (multiPoint)
			capture = cvCaptureFromAVI("../../videos/Filme2.avi");
		else
			capture = cvCaptureFromAVI("../../videos/3.avi");
	}
	if (!capture) {
		fprintf(stderr, "Could not initialize capturing...\n");
		exit(-1);
	}

	// initialize precache for spiral
	if (deep != 0)
		distance(deep);
	else
		distance(DEEP);

	//printSpiralDistance();

	captureWidth = 0;
	captureHeight = 0;

	spiralTentatives = 0;
	spiralSuceeded = 0;

	IplImage* frame = cvQueryFrame(capture);

	if (!frame) {
		printf("bad video \n");
		exit(0);
	}

#ifdef __WIN32__
	if(cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_WIDTH,captureWidth))
		printf("Cant set width property\n");

	if(cvSetCaptureProperty(capture, CV_CAP_PROP_FRAME_HEIGHT, captureHeight))
		printf("Cant set height property\n");

	if(cvSetCaptureProperty(capture, CV_CAP_PROP_FPS, captureFPS))
		printf("Cant set FPS\n");
#endif

	// Background subtraction
	bg_model = cvCreateGaussianBGModel(frame);
	//bg_model = cvCreateFGDStatModel(frame);


	showCaptureProperties(capture);

	puts("These are the comands to control the runtime aplication: \n\n");

	puts("\tPress Escape to quit\n");
	puts("\tPress Space to Change the process image algorithm\n");
	puts("\tPress \"C\" to print a circle on the estimate Point of interest\n");
	puts("\tPress \"M\" to start/stop the application control your mouse\n ");
	puts(
		"\tPress \"R\" to the aplication start reporting the coordinate of the Interest Point\n ");
	puts("\tPress \"+\" or \"-\" to control the threshold value\n ");
	puts("\tPress Backspace to reinitialize the Background Model\n\n ");
	puts("Background\n\n ");
	puts("\tPress \"B\" to calibrate the background\n ");
	puts("\tPress \"D\" to start/stop Background subtraction process\n ");

}


THREAD_RETURN_TYPE  Algorithms::_processVideo(void * obj)
{
	((Algorithms *)obj)->Process();
}
THREAD_RETURN_TYPE  Algorithms::_processIO(void * obj)
{
	((Algorithms *)obj)->interfaceIO();
}




void Algorithms::startProcessing()
{
	
	cvNamedWindow("Whiteboard Process", CV_WINDOW_AUTOSIZE);
	
	cvCreateTrackbar("Threshold", "Whiteboard Process", &threshold, 255, NULL);
	//cvCreateTrackbar("Step","Whiteboard Process",&step,20,NULL);
	
	
	if (debug) {
		cvNamedWindow("View", CV_WINDOW_AUTOSIZE);
	}
	
	//int fps=0;
	
	printf("\nSTART - %d\n", choice);
	
	printTime();

#ifdef WIN32 || WIN64
	hThread = (HANDLE)_beginthread(_processVideo, 0, this);
	ioThread = (HANDLE)_beginthread(_processIO, 0, this);
	// Need to join thread
	// SLEEP(1000000000);
#else
	pthread_create(&ioThread,NULL,_processIO,this);

	//pthread_create(&hThread,NULL,_processVideo,this);
	Process();

	void *status;
	pthread_join(ioThread, &status);
#endif
	puts("\nEND\n");
	printTime();
	//printf("\nTotal frame processed %d\n", i);
	if (spiralTentatives)
		printf(
		"Spiral analysis\n\tTry: %d\tSucess: %d (%d\%)\tFailed %d (%d\%)",
		spiralTentatives, spiralSuceeded, (spiralSuceeded * 100)
		/ spiralTentatives, spiralTentatives - spiralSuceeded,
		100 - ((spiralSuceeded * 100) / spiralTentatives));



}


void Algorithms::interfaceIO()
{
	for(;!Quit;)
	{
		//puts("THREAD IO");
		//keyPress= cvWaitKey(50);

		// escape
		if (keyPressValue == 27)
			Algorithms::Quit=true;

		// space
		if (keyPressValue == 32) {
			if (choice < 5)
				choice++;
			else
				choice = 1;

			printf("\n\nNew Algorithm: %d\n\n", choice);

		}
		// backspace
		if (keyPressValue == 8) {
			puts("Restart background\n");
			Algorithms::restartBackground = true;
		}
		// b or B
		if (keyPressValue == 66 || keyPressValue == 98) {
			puts("Calibrate\n");
			Algorithms::calibrate = true;
		}

		// c or C
		if (keyPressValue == 67 || keyPressValue == 99) {
			Algorithms::circle = !Algorithms::circle;
			printf("Circle %s\n", circle ? "on" : "off");

		}

		// d or D
		if (keyPressValue == 68 || keyPressValue == 100) {
			Algorithms::difer = !Algorithms::difer;
			printf("Difer %s\n", difer ? "on" : "off");
		}

		// m or M
		if (keyPressValue == 77 || keyPressValue == 109) {
			Algorithms::move = !Algorithms::move;
			printf("Move %s\n", move ? "on" : "off");
		}

		// r or R
		if (keyPressValue == 82 || keyPressValue == 114) {
			Algorithms::report = !Algorithms::report;
			printf("Report %s\n", report ? "on" : "off");
		}
		
		// f or F
		if (keyPressValue == 70 || keyPressValue == 102) {
			Algorithms::flipVertical = !Algorithms::flipVertical;
			printf("FLIP %s\n", flipVertical ? "on" : "off");
		}

		// +
		if (keyPressValue == 43) {
			threshold++;
			printf("\n\nNew threshold value: %d\n\n", threshold);
		}

		// -
		if (keyPressValue == 45) {
			threshold--;
			printf("\n\nNew threshold value: %d\n\n", threshold);

		}
		
		keyPressValue=0;
		SLEEP(100);
	}
}

coordinate Algorithms::Process() {


	coordinate temp = { -1, -1 };
	//int i;

		
	
	for (;!Quit;)
	{
		//puts("THREAD CAM");
		//IplImage* frame =cvLoadImage("../../images/410x399.png");
		IplImage* frame = cvQueryFrame(capture);

		if (!frame) {
			fprintf(stderr, "Error: frame is null \n");
			getchar();
			//break;
		}

		if (restartBackground) {
			// Background subtraction
			bg_model = cvCreateGaussianBGModel(frame);
			//bg_model = cvCreateFGDStatModel(frame);
			restartBackground = false;
		}

		if (calibrate) {
			puts("Start Calibration Process");
			haveCalibrate = true;

			for (int i = 0; i < 10; i++, frame = cvQueryFrame(capture))
				// bacground subtraction
				cvUpdateBGStatModel(frame, bg_model);

			calibrate = false;
			puts("Finish Calibration Process");
		}

		//fps= (int) cvGetCaptureProperty(capture,CV_CAP_PROP_FPS);
		//printf("\n\nFPS: %d", fps);

		if (captureWidth == 0) {
			captureWidth = frame->width;
			captureHeight = frame->height;
		}

		// calc will be process in workFrame
		IplImage* workFrame = NULL;
		IplImage* finalFrame = NULL;

		workFrame = cvCreateImage(cvSize(frame->width, frame->height),
			IPL_DEPTH_8U, 1);
		finalFrame = cvCloneImage(frame);

		if (difer && haveCalibrate) {
			cvAbsDiff(finalFrame, bg_model->background, finalFrame);
			cvThreshold(finalFrame, finalFrame, int((2*threshold)/3), 255, CV_THRESH_BINARY);
			cvUpdateBGStatModel(frame, bg_model);
		}
		// grayscale
		cvCvtColor(finalFrame, workFrame, CV_BGR2GRAY);

		if (flipVertical) {
			cvFlip(finalFrame, finalFrame, 1);
			cvFlip(workFrame, workFrame, 1);
		}

		// blur image
		if (Blur) {
			cvSmooth(workFrame, workFrame, CV_BLUR);
			cvSmooth(finalFrame, finalFrame, CV_BLUR);
		}

		switch (choice) {
		case 1:
			temp = singlePointProcess(workFrame);
			break;

		case 2:
			temp = singlePointProcess(workFrame, step);
			break;

		case 3:
			temp = singlePointProcessPTR(workFrame, step);
			break;

		case 4:
			temp = smartSinglePointProcess(workFrame);
			break;

		case 5:
			results = detectBlobs(workFrame, finalFrame);
			break;

		default:
			temp = singlePointProcessPTR(workFrame, step);
			break;
		}

		if (choice == 5 && !multiPoint) {
			if (results.size() > 0)
				temp = results.at(0);
			else {
				temp.x = -1;
				temp.y = -1;
			}
		}

		

		if (!multiPoint) {
			if (report)
				reportCoordinate(temp);
			if (circle && choice != 5)
				printCircle(temp, finalFrame);
			if (move) {

				temp = convertToScale(temp);
				
				lastPoint = presentPoint;
				presentPoint = temp;
				
				qtMove(temp.x, temp.y);
				
				//qtMove(convertToResolution(temp.x,workFrame->width,screenWidth),convertToResolution(temp.y,workFrame->height,screenHeight));

				interpreter();
			}
		}
		
		
		
		// Print Calibration
		for(int i=0;i<=3;i++)
			printCircle(projection[i], finalFrame);
		

		cvShowImage("Whiteboard Process", finalFrame);

		if (debug) {
			cvShowImage("View", frame);
		}

		cvReleaseImage(&workFrame);
		cvReleaseImage(&finalFrame);

		keyPressValue=cvWaitKey(200);
		//SLEEP(200);
	}

	return temp;
}

void Algorithms::interpreter() {
	aproximation = 5;
	
	
	if (keyPress) {
		
		if (presentPoint.x != -1 && presentPoint.y != -1) {
			if((tryPoint.x + aproximation) >= presentPoint.x
			   && (tryPoint.x - aproximation) <= presentPoint.x 
			   && (tryPoint.y + aproximation) >= presentPoint.y
			   && (tryPoint.y - aproximation) <= presentPoint.y )
				countRightClic++;
			
			
#ifdef __APPLE__
			postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,1);
#endif

			puts("\nKey Press Move");
		} else {
#ifdef __APPLE__
			postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,0);
#endif

			keyPress = false;

			puts("\nKey Up");
		}

	} 
	else 
	{
		// find a right clic
		if (wantToClic && (tryPoint.x + aproximation) >= presentPoint.x
				&& (tryPoint.x - aproximation) <= presentPoint.x 
				&& (tryPoint.y + aproximation) >= presentPoint.y
				&& (tryPoint.y - aproximation) <= presentPoint.y ) 
		{
			wantToClic = false;
			// emular o clic direito
#ifdef __APPLE__
			postMouseEventApple(presentPoint.x,presentPoint.y,captureWidth,captureHeight,1);
#endif
				
			keyPress = true;
				
			puts("\nKey press");
				
				
				
		}
		
		if (lastPoint.x == -1 && lastPoint.y == -1 && presentPoint.x != -1
			&& presentPoint.y != -1) 
		{
			tryPoint.x = presentPoint.x;
			tryPoint.y = presentPoint.y;
			wantToClic = true;
				
			keyPress= false;
				
			puts("\nWant to clic");
		}

	}
	if(countRightClic == 5)
	{
		rightClic=true;
	}
	
	if(rightClic)
	{
		postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,0);
		postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,1);
		postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,0);
		postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,1);
		postMouseEventApple(lastPoint.x,lastPoint.y,captureWidth,captureHeight,0);
		
		countRightClic=0;
		rightClic=false;
		keyPress = false;
		
		puts("Double right clic");
	}
}

#ifdef __APPLE__
void Algorithms::postMouseEventApple(int x, int y, int width, int height,int click)
{
	CGPoint pt;
	CGEventRef eventRef=NULL;

	//pt.x = convertToResolution(x,width,screenWidth);
	//pt.y = convertToResolution(y,height,screenHeight);

	pt.x=x;
	pt.y=y;
	
	CGPostMouseEvent( pt, 1, 1, click);
	
	/*
	if(click)
	{
		eventRef=CGEventCreateMouseEvent (NULL,kCGEventLeftMouseDown,pt,0);
		CGEventPost (kCGHIDEventTap,eventRef);
		CFRelease(eventRef);
	}
	else
	{
		eventRef=CGEventCreateMouseEvent (NULL,kCGEventLeftMouseUp,pt,0);
		CGEventPost (kCGHIDEventTap,eventRef);
		CFRelease(eventRef);
	}
	*/
}
#endif

void Algorithms::verticalFlipON() {
	Algorithms::flipVertical = true;
}

void Algorithms::verticalFlipOFF() {
	Algorithms::flipVertical = false;
}

void Algorithms::blurON() {
	Algorithms::Blur = true;
}

void Algorithms::blurOFF() {
	Algorithms::Blur = false;
}

void Algorithms::setStep(int value) {
	Algorithms::step = value;
}

void Algorithms::setJumpSpiral(int value) {
	Algorithms::jumpValue = value;
}



void Algorithms::setSpiralDeep(int value) {
	Algorithms::deep = value;
}

void Algorithms::printTime() {
	time_t now;
	struct tm ts;
	char buf[80];

	// Get the current time
	time(&now);

	// Format and print the time, "hh:mm:ss "
	ts = *localtime(&now);
	strftime(buf, sizeof(buf), "%H:%M:%S", &ts);
	printf("%s\n", buf);
}

void Algorithms::printSpiralDistance() {
	puts("\nStart - Spiral distances\n");
	for (int i = 0; i < (int) vDistance.size(); i++) {
		printf("\n%d\tx: %d\ty: %d\n", i, vDistance.at(i).x, vDistance.at(i).y);
	}
	puts("\nEnd - Spiral distances\n");
}

void Algorithms::setCapture(int captureFPS, int captureWidth, int captureHeight) {
#ifdef __WIN32__
	Algorithms::captureFPS=captureFPS;
	Algorithms::captureHeight=captureHeight;
	Algorithms::captureWidth=captureWidth;
#else
	printf("\nThis functionality only work in windows platform (setCapture).\n");
#endif
}

void Algorithms::showCaptureProperties(CvCapture* cap) {
#ifdef __WIN32__
	int w,h,f;
	w=(int)cvGetCaptureProperty(cap,CV_CAP_PROP_FRAME_WIDTH);
	h=(int)cvGetCaptureProperty(cap,CV_CAP_PROP_FRAME_HEIGHT);
	f=(int)cvGetCaptureProperty(cap,CV_CAP_PROP_FPS);
	printf("Capture properties (widthxheight - frames): %dx%d - %d\n",w,h,f);
#else
	printf(
		"\nThis functionality only work in windows platform (showCaptureProperties).\n");
#endif
}


void Algorithms::startCalibrate() {
	cvNamedWindow("Calib", CV_WINDOW_AUTOSIZE);
	//cvNamedWindow("DEBUG", CV_WINDOW_AUTOSIZE);
#ifdef __APPLE__
	char * fileName="../../images/background800x600White.png";
#endif
#ifdef WIN32
	char * fileName="C:\\projects\\christophe_v03\\images\\background.JPG";
#endif
	IplImage* img = cvLoadImage(fileName);
	if (!img)
		printf("Could not load image file: %s\n", fileName);

	puts("Start Calibration Process");
	IplImage * frame = cvQueryFrame(capture);


	
	cvMoveWindow("Calib", 0, 0);
	cvShowImage("Calib", img);
	imgHeight = img->height;
	imgWidth = img->width;
	int d = 20;

	printf("\n ScreenWidth : %d \t ScreenHeight : %d\n",screenWidth,screenHeight);
	cvResizeWindow("Calib",screenWidth,screenHeight);

	bg_model = cvCreateGaussianBGModel(frame);
	//bg_model = cvCreateFGDStatModel(frame);
	for (int i = 0; i < 20; i++, frame = cvQueryFrame(capture))
		// background subtraction
		cvUpdateBGStatModel(frame, bg_model);
	puts("Finish Calibration Process");
		

	// Referecences points in the image background
	coordinate p1 = { d, d }, p2 = { imgWidth - d, d },
		p3 = { d, imgHeight - d }, p4 = { imgWidth - d, imgHeight - d };
	references[0] = p1;
	references[1] = p2;
	references[2] = p3;
	references[3] = p4;

	for (int i = 0; i <= 3; i++) {
		img = cvLoadImage(fileName);
		printCircle(references[i], img);
		cvShowImage("Calib", img);
		bool point = false;
		coordinate temp;
		while (!point) 
		{
			frame = cvQueryFrame(capture);

			IplImage* workFrame = NULL;

			cvAbsDiff(frame, bg_model->background, frame);
			cvThreshold(frame, frame, int((2*threshold)/3),	255, CV_THRESH_BINARY);
			cvUpdateBGStatModel(frame, bg_model);

			
			if (flipVertical) {
				cvFlip(frame, frame, 1);
			}

			workFrame = cvCreateImage(cvSize(frame->width, frame->height),
				IPL_DEPTH_8U, 1);
			cvCvtColor(frame, workFrame, CV_BGR2GRAY);

			temp = singlePointProcess(workFrame);

			if(temp.x==-1 || temp.y==-1)
			{
				keyPressValue=cvWaitKey(200);
				cvUpdateBGStatModel(frame, bg_model);
			}
			else
			{
				if (temp.x > -1 && temp.y > -1 && temp.x < frame->width && temp.y
					< frame->height && temp.x != projection[i - 1].x && temp.y
					!= projection[i - 1].y) 
				{
					cvReleaseImage(&img);
					img = cvLoadImage(fileName);
					cvShowImage("Calib", img);
					
					cvReleaseImage(&workFrame);
					cout << '\a' << flush;
					point = true;
				}
			}
			

		}

		printf("\nCalib Point : %d\n", i + 1);
		projection[i] = temp;

		printCircle(temp, frame);
		//cvShowImage("DEBUG",frame);
		keyPressValue=cvWaitKey(1000);
	}

	cvDestroyWindow("Calib");
	cvReleaseImage(&img);
	puts("Destroy calibrate");
	//cvDestroyWindow("DEBUG");

	
	// Referecences assume screen resolution rectangle
	coordinate r1 = { d, d }, r2 = { screenWidth - d, d },
	r3 = { d, screenHeight - d }, r4 = { screenWidth - d, screenHeight - d };
	references[0] = r1;
	references[1] = r2;
	references[2] = r3;
	references[3] = r4;
	

	printf(
		"\nRectangle Original [%d,%d][%d,%d][%d,%d][%d,%d]\nRectangle Projectado [%d,%d][%d,%d][%d,%d][%d,%d]\n",
		references[0].x, references[0].y, references[1].x, references[1].y,
		references[2].x, references[2].y, references[3].x, references[3].y,
		projection[0].x, projection[0].y, projection[1].x, projection[1].y,
		projection[2].x, projection[2].y, projection[3].x, projection[3].y);

	// set scale
	setScale();
}

void Algorithms::setScale() {
	// inicialização da matriz transferencia
	mat_trf = cvCreateMat(3,3,CV_32FC1);

	srcQuad[0].x = projection[0].x; srcQuad[0].y = projection[0].y; // src Top Left
	srcQuad[1].x = projection[1].x; srcQuad[1].y = projection[1].y; // src Top Right
	srcQuad[2].x = projection[2].x; srcQuad[2].y = projection[2].y; // src Bottom Left
	srcQuad[3].x = projection[3].x; srcQuad[3].y = projection[3].y; // src Bottom Right

	dstQuad[0].x = references[0].x; dstQuad[0].y = references[0].y; // dst Top Left
	dstQuad[1].x = references[1].x; dstQuad[1].y = references[1].y; // src Top Right
	dstQuad[2].x = references[2].x; dstQuad[2].y = references[2].y; // src Bottom Left
	dstQuad[3].x = references[3].x; dstQuad[3].y = references[3].y; // src Bottom Rightset

	cvGetPerspectiveTransform(srcQuad, dstQuad, mat_trf);

}

coordinate Algorithms::convertToScale(coordinate temp) {
	if (temp.x==-1 && temp.y==-1)
		return temp;
	CvMat* src_point = cvCreateMat( 1, 1, CV_32FC2);
	CvMat* dst_point = cvCreateMat( 1, 1, CV_32FC2);

	// exemplo de transformação
	float *data_src = src_point->data.fl;
	float *data_dst = dst_point->data.fl;

	data_src[0] = temp.x; data_src[1] = temp.y; // src point (x,y)
	

	// transforma pontos
	cvPerspectiveTransform(src_point, dst_point, mat_trf);
	

	//printf("src(x=%f,y=%f) ->\t dst(x=%f,y=%f)\n",data_src[0],data_src[1],data_dst[0],data_dst[1]);
	
	temp.x=data_dst[0]; temp.y= data_dst[1];
	return temp;
}

